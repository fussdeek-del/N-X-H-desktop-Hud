import ctypes
import time
from tkinter import messagebox

from config import SINGLE_INSTANCE_NAME, UPDATE_INTERVAL_MS
from core.formatter import format_metrics
from core.metrics import collect_metrics, prime_metrics
from core.sender import SerialSender


def acquire_single_instance():
    kernel32 = ctypes.windll.kernel32
    mutex = kernel32.CreateMutexW(None, False, SINGLE_INSTANCE_NAME)
    already_exists = kernel32.GetLastError() == 183
    if already_exists:
        messagebox.showinfo("HUD Monitor", "HUD Monitor is already running.")
        return None
    return mutex


def main():
    mutex = acquire_single_instance()
    if mutex is None:
        return

    prime_metrics()
    sender = SerialSender()

    try:
        while True:
            started = time.monotonic()
            payload = collect_metrics()
            sender.send(format_metrics(payload))
            elapsed = time.monotonic() - started
            sleep_for = max(0, (UPDATE_INTERVAL_MS / 1000) - elapsed)
            time.sleep(sleep_for)
    except KeyboardInterrupt:
        pass
    finally:
        sender.close()
        ctypes.windll.kernel32.ReleaseMutex(mutex)


if __name__ == "__main__":
    main()
